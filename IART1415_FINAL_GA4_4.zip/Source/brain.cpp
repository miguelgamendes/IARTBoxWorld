#include "brain.h"

void astar(map map, int originX, int originY, int destinationX, int destinationY) {

}