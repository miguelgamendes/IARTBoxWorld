#pragma once

#include "map.h"

class Brain {
	void astar(map map, int originX, int originY, int destinationX, int destinationY);
};